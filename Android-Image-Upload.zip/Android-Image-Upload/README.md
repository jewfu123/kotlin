# Android-Image-Upload
<h3>this program uses the eclipse,included  the method to upload  picture from the camera or the album and the method to compress the picture</h3>
