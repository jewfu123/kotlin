package com.mutkuensert.bitmapcompression

//class SizeException(override val message: String) : RuntimeException(message)